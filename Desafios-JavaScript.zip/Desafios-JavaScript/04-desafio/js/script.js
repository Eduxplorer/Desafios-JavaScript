let number = parseInt(prompt("Digite um número"));
for (let i = 1; i <= 10; i++) {
    console.log(`${i} * ${number} = ${i * number}`)
}

