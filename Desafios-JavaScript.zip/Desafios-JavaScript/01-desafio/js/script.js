let number = prompt("Digite um número")
let number2 = prompt("Digite outro número")

if (number > number2) {
    console.log(number)
} else {
    console.log(number2)
}