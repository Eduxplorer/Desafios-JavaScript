let verificarParOuImpar = prompt("Digite um número para verificar se é par ou impar")

if (verificarParOuImpar % 2 === 0) {
    console.log('O número é Par')
} else {
    console.log("O número é Impar")
}