let number = 1;

while (number <= 100) {
  console.log(number);
  number++;
}

// for (let i = 1; i <= 100; i++) {
//     console.log(i);
// }
