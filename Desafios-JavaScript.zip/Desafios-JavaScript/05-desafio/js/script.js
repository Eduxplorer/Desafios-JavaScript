let n1 = parseInt(prompt("Digite um número"))

if (n1 > 0) {
    console.log("Seu número é positivo!")
} else if (n1 == 0) {
    console.log("Seu número é igual a zero!")
} else {
    console.log("Seu número é negativo!")
}